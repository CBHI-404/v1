#usr/bin!/bash
Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal='\033[34;1m'
GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal='\033[34;1m'
ZzByLlNnbGsifgqiGald='\033[34;1m'
B='\033[34;1m' 
G='\033[32;1m' 
P='\033[35;1m' 
C='\033[36;1m' 
R='\033[31;1m' 
W='\033[37;1m' 
Y='\033[33;1m' 
BL='\033[0;30m' 
bi='\033[34;1m'
i='\033[32;1m'
pur='\033[35;1m'
cy='\033[36;1m'
me='\033[31;1m'
pu='\033[37;1m'
ku='\033[33;1m'
hi='\033[0;30m'
mer='\033[41;97m' #Tepi
st='\033[0m' #Stop
echo $R"  ____________
  ║▒▒▒▒▒▒▒▒▒▒║
  ║▒▒▒▒▒▒▒▒▒▒║
  ║▒▒▒▒▒▒▒▒▒▒║  ${Y}╔╗╔╔═╗╔╦╗╔═╗"
echo $bi" ╔════════════╗${Y} ║║║╠═╣║║║╠═╣"
echo "${B} ╚════════════╝${Y} ╝╚╝╩ ╩╩ ╩╩ ╩"
echo "${B}  ║${Y}██████████${B}╚╗${Y} ╦╔═╔═╗╔╦╗╦ ╦"
echo "${B}  ║${Y}██${R}╔══╗${Y}█${R}╔═╗${Y}█${B}║${Y} ╠╩╗╠═╣║║║║ ║"
echo "${B}  ║${Y}██${R}║${Y}╬${R}╔╝${Y}█${R}╚╗${R}║${Y}█${B}║${Y} ╩ ╩╩ ╩╩ ╩╚═╝"
echo "${B}  ║${Y}██${R}╚═╝${Y}█${R}║${Y}█${R}╚╝${Y}█${B}║${W} Isi Dengan Benar *_*"
echo "${B}  ╚╗${Y}█████████${B}═╝"
echo "${B}   ╚╗${B}║${R}╠╩╩╩╩╩╝"
echo "${B}    ║${B}║${W}┈┈┈${Y}█${B}▐█████${R}▒${C}.｡oO"
echo "${B}    ║${Y}██${R}╠╦╦╦╗"
echo "${B}    ╚╗${Y}██████${W} Author${R}:${B}Mr_!nSt4rneXt1"
echo "${B}     ╚════╝${W}Team${R}:${B}Cyber Hacking Indonesia"
echo "${W} <${Y}════════════════${W}X${Y}═════════════════${W}>"
echo ${W}
read -p"[•]MASUKAN NAMA KAMU: " name
sleep 1
clear
sh time.sh
sleep 1
sh coder.sh
python2 Gshdbsbsgagabdhxhaishdbd.py
sleep 1
echo
echo "${B}╔════════════════════════╗"
echo "${B}║${W} Welcome To${R}:${Y} $name"
echo "${B}╚════════════════════════╝"
sleep 1
echo
echo ${B}${B}"╔${B}═${B}${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}═══════════════════╗"
z= sleep 0.4
echo ${B}${B}"║"${W} "Versi 2.5"${Y} "(Update) "${B}"║"
echo ${B}${B}"╚════════════════════╝"${Y}
z= sleep 1
echo
echo $bi"╔══════════════════════════╗"${Y}
z=     date
echo $bi"╚══════════════════════════╝"
z= sleep 1
timed-read
echo "${R}╔${R}═${R}═${R}═${R}═${R}╗${R}╔${R}═${R}════${R}══${R}${R}${R}${R}══${R}═${R}${R}════════════╗╔══════════╗${R}${R}"
echo "${R}║${Y}{${W}N${W}O${Y}}${R}║${R}║${Y}  {${W} K${W}U${W}M${W}P${W}U${W}L${W}A${W}N T${W}O${W}OL${W}S${Y} }${R}  ║${R}║${Y}{${W} S${W}T${W}A${W}T${W}US${Y} }${R}║"
echo "${R}╚${R}═${R}═══${R}╝${R}╚═${R}═${R}═════${R}═════════${R}${R}${R}${R}════> ╚╝ <══${R}${R}══════╝"
echo "${B}╔${B}═${B}═══╗╔${B}══${B}══════${B}${B}${B}═════════${B}${B}═════${B}${B}╗   ╔════╗"
echo ${B}${B}"${B}║${Y} 0${Y}1${B} ║${B}║${W}${W} B${W}${W}r${W}o${W}w${W}s${W}i${W}n${W}g${W}${W} ${W}T${W}e${W}r${W}${W}m${W}ux${Y}${Y} (${Y}N${Y}e${Y}w${Y})${B}║  ║${Y}  O${Y}N${B}${B}  ║"
echo ${B}"${B}╚${B}═${B}═${B}═${B}═${B}╝${B}╚═══${B}═${B}${B}${B}══${B}═${B}════════${B}══${B}══${B}${B}═══╝   ${B}${B}╚═${B}═${B}═${B}═╝"
echo "${B}╔${B}═${B}═${B}═${B}═╗╔════════════════════${B}═${B}═╗   ${B}╔${B}═${B}═${B}═${B}═╗"
echo ${B}${B}${B}"${B}${B}║${Y} 0${Y}${Y}2${B} ║${B}${B}║${W}${W}K${W}${W}a${W}l${W}k${W}u${W}la${W}t${W}o${W}r ${W}T${W}e${W}r${W}m${W}ux${Y}(${Y}N${Y}e${Y}w${Y})${B}║${B}${B}  ║${Y}${Y}  O${Y}N${B}${B}  ║"
echo "${B}╚${B}════${B}╝${B}╚═${B}${B}${B}═${B}═${B}═${B}═${B}═${B}${B}${B}═${B}═══════════${B}${B}════${B}╝   ╚${B}${B}════╝"
z= sleep 0.4
echo ${B}${B}${B}"${B}╔${B}═${B}═${B}═${B}═${B}╗╔═══${B}${B}${B}${B}═══${B}${B}═══${B}═${B}═${B}══${B}════════${B}═╗${B}${B}   ╔════╗"
echo "${B}║${Y}${Y} 0${Y}3${B} ║${B}║${W} H${W}a${W}${W}ck ${W}S${W}${W}a${W}t${W}el${W}it${Y} (${Y}${Y}${Y}p${Y}r${Y}a${Y}nk${Y})${B} ║${B}${B}  ║${Y}  O${Y}N${B}${B}  ║"${B}${B}${B}
echo ${B}${B}"${B}╚${B}═${B}═${B}══${B}╝╚${B}═${B}══${ZzByLlNnbGsifgqiGald}══${B}══${B}${B}══${ZzByLlNnbGsifgqiGald}${B}════${B}═════${ZzByLlNnbGsifgqiGald}════${B}╝   ╚════╝"
echo ${ZzByLlNnbGsifgqiGald}"${B}${ZzByLlNnbGsifgqiGald}╔═${B}═══${bi}╗${B}${B}╔═${B}══════${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}═══════${B}════════${B}╗${B}   ${B}╔${B}${B}════${B}╗"
echo "${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}║${Y} 0${Y}4${ZzByLlNnbGsifgqiGald} ║${B}║${W} D${W}D${W}OS ${W}A${W}t${W}ta${W}ck${Y} (${Y}N${Y}e${Y}w${Y})${ZzByLlNnbGsifgqiGald}${B}    ║${B}  ║${Y}${Y}  O${Y}${Y}N${ZzByLlNnbGsifgqiGald}  ║"
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${ZzByLlNnbGsifgqiGald}╚${ZzByLlNnbGsifgqiGald}════${B}╝╚${B}═══════${ZzByLlNnbGsifgqiGald}══════════${ZzByLlNnbGsifgqiGald}════${ZzByLlNnbGsifgqiGald}═╝   ${B}${B}╚${ZzByLlNnbGsifgqiGald}════╝"
z= sleep 0.4
echo "${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╔${B}═${B}═${B}${B}══╗${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╔═${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}═══════════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}═════════${B}═╗   ╔${B}══${B}══╗"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${ZzByLlNnbGsifgqiGald}║${Y} 0${Y}${Y}5${B} ║${B}║${ZzByLlNnbGsifgqiGald}${W} P${W}e${W}rc${W}ep${W}a${W}t I${W}nt${W}er${W}net${W}🚀${ZzByLlNnbGsifgqiGald}  ║${ZzByLlNnbGsifgqiGald}  ║${Y}${Y}  O${Y}N${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}  ║"
echo ${B}${B}"╚══${B}${B}══╝╚═════════${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}════════════${B}${B}═╝  ${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal} ╚════╝"${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}
echo ${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}"╔═══${B}═╗╔═${B}${B}════════${B}═══════════${B}══╗   ╔════╗"
echo ${ZzByLlNnbGsifgqiGald}"${B}║${Y} 0${Y}6${B} ║${B}║${W} T${W}o${W}m${W}b${W}ol ${W}S${W}p${W}e${W}c${W}i${W}a${W}l${Y} (${Y}N${Y}e${Y}w${Y})${B}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal} ║${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}  ║${Y}  O${Y}N${ZzByLlNnbGsifgqiGald}  ║"${ZzByLlNnbGsifgqiGald}
echo "${ZzByLlNnbGsifgqiGald}╚════╝${ZzByLlNnbGsifgqiGald}╚═══${B}${B}═════${B}══════${ZzByLlNnbGsifgqiGald}════════╝   ╚════╝"
z= sleep 0.4
echo ${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}"╔═${B}══${B}${B}═╗╔${B}══${ZzByLlNnbGsifgqiGald}════${ZzByLlNnbGsifgqiGald}═════════════${ZzByLlNnbGsifgqiGald}═══╗   ╔════╗"
echo ${B}${B}"${B}║${Y} 0${Y}7${B} ║${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}║${W} T${W}o${W}o${W}ls${W} R${W}u${W}s${W}ma${W}n${W}a${Y} (N${Y}e${Y}w${Y})${B}  ║${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${B}${B}"${B}╔${B}═${B}═${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}══╗╔════════════════════${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}══╗   ╔════╗"${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}║${Y} ${Y}0${Y}8${B} ║${B}║${W} J${W}oi${W}n ${W}G${W}r${W}ou${W}p ${W}Wa${Y} (${Y}N${Y}e${Y}w${Y})${B}  ║${B}  ║${Y}  O${Y}N${B}  ║"${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}
echo ${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}"╚════╝╚${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}═════════════════════${B}${B}═╝   ╚════╝"
z= sleep 0.4
echo ${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}"╔${B}═${B}═${B}${B}${B}══╗╔═══════════════${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}═══════╗   ╔${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}════╗"
echo ${B}${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}"${B}║${Y} 0${Y}9${B} ║${B}║${W} N${W}i${W}c${W}k${W} A${W}g${W}g${W}o${W}t${W}a${W} C${W}B${W}H${W}I${B}     ║${B}  ║${Y}  O${Y}N${B}  ║"${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}
echo ${B}"╚═${B}═${B}═${B}═${B}${B}╝${B}╚${B}════════${B}══════${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}════════╝   ╚════╝"
echo ${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}${B}"${B}╔${B}═${B}═${B}══╗${B}╔═${B}═════${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}══════════════${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}══╗   ╔═══${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}═╗"
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}║${Y} 1${Y}0${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal} ║${B}║${W} C${W}ha${W}n${W}n${W}e${W}l ${W}Y${W}o${W}ut${W}u${W}be${W} A${W}d${W}min${B}║${B}${B}  ║${R} C${R}o${R}i${R}d${B}${B} ║"
echo ${B}"╚${B}${B}════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╝╚${B}═${B}═${B}${B}═════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}════════════${B}${B}═══╝${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}   ╚${B}═${B}═══╝"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}
echo ${B}"${B}╔${B}═${B}═${B}═${B}═${B}╗${B}╔═════════════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}═════${B}═══${B}═╗${B}${B}   ${B}╔${B}═${B}══${B}═${B}╗"
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${B}║${Y} 1${Y}1${B} ║${B}${B}${B}${Y}${B}║${W} H${W}ac${W}k${W} I${W}n${W}s${W}t${W}ag${W}ram${Y} (${Y}N${Y}e${Y}w${Y})${B} ║${B}  ║${Y}  ON${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}  ║"
echo ${B}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╚═══${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}═╝╚${B}═${B}${B}═${B}════════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}════════${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}════╝ ${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}  ╚${B}═${B}═${B}${B}${Y}${W}${B}══╝"${B}${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}
z= sleep 0.4
echo ${B}${B}"${B}╔${B}${B}═${B}═${B}═${B}═${B}╗${Y}${W}${G}${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╔${B}═${B}═${B}══${B}═${B}═${B}═${B}═══════${B}════${B}═══${B}═╗${B}${B}   ╔${B}═${B}═${B}══╗"
echo ${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"${B}║${Y} 1${Y}2${B} ║${B}║${W} V${W}i${W}ru${W}s M${W}a${W}rk${W}er${Y} (${Y}N${Y}e${Y}w${Y})${B}${B}   ║${B}  ║${Y}  O${Y}${Y}N${B}${B}  ║"
echo ${B}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╚${B}═${B}${B}═${B}══${B}╝"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}"╚${B}═${B}══${B}════${B}${B}${B}════${B}═${B}═${B}══${B}═${B}═${B}═════╝"${B}${B}${Y}${W}${G}${B}   "  ╚${B}═${B}═${B}═${B}${B}═╝"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}
echo ${Y}${W}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╔${B}═${B}═${B}${B}═${B}═╗${B}╔${B}═${B}═${B}══════════${B}${B}════════${B}${B}══╗${B}   ╔${B}═${B}═${B}═${B}═╗"
echo ${W}"${B}║${Y} 1${Y}3${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal} ║${B}${B}${Y}${W}${B}║${W} C${W}h${W}at${W} A${W}d${W}mi${W}n${Y} (${Y}N${Y}e${Y}w${Y})${B}${B}${B}     ║${B}${Y}${W}${B}  ║${Y}  O${Y}N${B}${B}  ║"
echo "${B}╚${B}${B}══${B}═${B}${B}═╝╚══${ZzByLlNnbGsifgqiGald}══════${B}══${W}${R}${B}═══${B}${B}═══════${B}══╝   ${B}╚${B}${B}══${B}══╝"
echo ${ZzByLlNnbGsifgqiGald}${B}${B}"╔════${B}╗╔${B}═${B}${B}══${ZzByLlNnbGsifgqiGald}═══════════════════╗   ╔════╗"
echo "${B}║${Y} 1${Y}4${B} ║${B}║${W} V${W}i${W}r${W}us ${W}Mar${W}k${W}er${Y} (${Y}pr${Y}a${Y}n${Y}k${Y})${B} ║${B}${B}  ║${Y}${W}${B}${Y}  O${Y}N${B}${B}  ║"
echo ${B}"${B}╚${B}${Y}${W}${R}${B}════╝╚══════════════════════╝   ╚════╝"
z= sleep 0.4
echo ${B}"${B}╔${B}═${B}═${B}${B}══${B}╗╔${B}${B}════════${B}${B}═══════${B}═══════╗   ╔════╗"
echo ${ZzByLlNnbGsifgqiGald}"║${Y} 1${Y}${Y}5${B} ║${B}║${W} H${W}a${W}ck${W} C${W}${W}CT${W}V${Y} (${Y}N${Y}e${Y}w)${B}      ║${B}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}"╔═══${B}${B}═╗╔═══${B}═══════════════════╗   ╔════╗"
echo ${B}"║${Y} 1${Y}6${B} ║║${W} H${W}a${W}c${W}k F${W}${W}B${Y} (${Y}p${Y}ra${Y}nk)${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}      ║  ║${R} C${R}oi${R}d${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal} ║"
echo ${B}"╚${B}═${B}${B}═══╝${B}╚═══${B}${B}════════${B}═${B}═${B}═════════╝   ╚════╝"
echo ${B}${B}"╔════╗${B}╔═${B}${B}═════════════════════╗   ╔════╗"
echo "${B}${B}${B}║${Y} 1${Y}7${B} ║${B}║${W}Pe${W}rk${W}i${W}r${W}aa${W}n ${W}C${W}ua${W}ca${W}⛅${Y}(${Y}N${Y}ew${Y})${B}║  ║${Y}${Y}${Y}  ON${W}${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
z= sleep 0.4
echo ${B}"${B}╔${B}${B}════╗${B}╔═${B}══════════════${B}${Y}${R}${W}${B}${BL}${B}═══════╗${B}${B}   ╔════╗"
echo ${B}${B}"║${Y} 1${Y}8${B} ║${B}║${W} T${W}u${W}an${W} B${W}ad${W}u${W}t${Y} (${Y}v${Y}3${Y})${B}      ║${B}  ║${Y}  O${Y}N${B}  ║"
echo "${B}╚${B}══${B}══${B}╝╚${B}══${B}══${B}═════════${B}═════${B}════╝   ╚════╝"
echo ${B}"╔════╗╔══════════════════════╗   ╔════╗"
echo ${bi}"║${Y} 1${Y}9${B} ║${B}║${W} S${W}p${W}am${W} W${W}a${Y} (${Y}pr${Y}ank${Y})${B}${B}      ║${B}${B}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚═${B}═${B}═${B}═${B}╝${B}╚${B}═${B}═${B}═${B}${B}═════${B}═${B}══${B}═══════════╝   ╚════╝"
echo ${B}"╔${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}════╗╔══════════════════════╗   ╔════╗"
echo ${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}"${B}║${Y} 2${Y}${Y}0${B}${B} ║║${W} In${W}f${W}o ${W}Up${W}${W}${W}date${Y}${Y} (${Y}N${Y}e${Y}w${Y})${B}    ║  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚═${B}═${B}${B}══╝╚═${B}${B}═══════════════${B}${B}══════${B}╝   ╚${B}${B}═${B}═══╝"
z= sleep 0.4
echo ${B}"╔════╗╔══════════════════════╗   ╔════╗"
echo ${bi}"║${Y} 2${Y}1${B} ║${B}║${W} J${W}a${W}sa${W} A${W}dmin${Y} (${Y}F${Y}ree${Y})${B}${B}    ║${B}${B}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${B}"╔════╗╔══════════════════════╗   ╔════╗"
echo ${B}${B}"${B}║${Y} 2${Y}2${B} ║${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}║${W} T${W}o${W}o${W}ls${W} D${W}a${W}r${W}kF${W}B${Y} (V${Y}i${Y}p${Y})${B}   ║${ZzByLlNnbGsifgqiGald}${ZzByLlNnbGsifgqiGald}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${B}"╔════╗╔══════════════════════╗   ╔════╗"
echo ${bi}"║${Y} 2${Y}3${B} ║${B}║${W} T${W}o${W}ol${W}s${W} Pajaoq     ${B}${B}    ║${B}${B}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${B}"╔════╗╔══════════════════════╗   ╔════╗"
echo ${bi}"║${Y} 2${Y}4${B} ║${B}║${W} S${W}e${W}nd${W} T${W}rojan${Y} (${Y}N${Y}ew${Y})${B}${B}    ║${B}${B}  ║${Y}  O${Y}N${B}  ║"
echo ${B}"╚════╝╚══════════════════════╝   ╚════╝"
echo ${Y}${W}"${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal}╔${B}═${B}═${B}${B}═${B}═╗${B}╔${B}═${B}═${B}══════════${B}${B}════════${B}${B}══╗${B}   ╔${B}═${B}═${B}═${B}═╗"
echo ${W}"${B}║${Y} 2${Y}5${GhLgdbacVvGbBdialfoahPodnGgsHhnsalVvsjFaddjal} ║${B}${B}${Y}${W}${B}║${W} S${W}p${W}am ${W}W${W}a ${Y}K${Y}i${Y}t${Y}a${Y}b${Y}is${Y}a${W}.${Y}com${Y}${B}${B}${B} ║${B}${Y}${W}${B}  ║${Y}  O${Y}N${B}${B}  ║"
echo "${B}╚${B}${B}══${B}═${B}${B}═╝╚══${ZzByLlNnbGsifgqiGald}══════${B}══${W}${R}${B}═══${B}${B}═══════${B}══╝   ${B}╚${B}${B}══${B}══╝"
echo ${B}${Y}${W}${B}"╔${B}═${B}═${B}══${B}╗╔═${B}══${B}═${B}═${B}═${B}═${B}═╗"
echo ${Ggbdkalduwga0Jdgdoq72hdhHdglp0ohsjsnOo0jsjs0pisoohOhdhal}"║${R} 0${R}0${B} ║║${R} K${R}e${R}lu${R}ar${B} ║"
echo ${B}"╚${B}═${B}═${B}═${B}═${B}╝╚${B}═${B}═${B}═${B}═════╝"${W}""
z= sleep 1
z= bash GdhdjGfdhdkHdhdbVxgdhshVdbskajdhGgfbfjsksjdjdkdk.sh
z= sleep 1
echo ${W}
read -p "[+]Pilih Nomor: " p

if [ $p = 01 ] || [ $p = 1 ];then
eval; cd browsing_di_termux
eval; sh browsing.sh
fi

if [ $p = 02 ] || [ $p = 2 ];then
eval; cd Kalkulator_Termux
eval; sh kal.sh
fi

if [ $p = 03 ] || [ $p = 3 ];then
eval; cd hack_satelit
eval; cd HekSatelit
eval; sh Hek.sh
fi

if [ $p = 04 ] || [ $p = 4 ];then
eval; cd Ddos_Attack
eval; sh logo.sh
eval; python2 LITEDDOS.py
fi

if [ $p = 05 ] || [ $p = 5 ];then
eval; cd percepat_internet
eval; sh logo.sh
fi

if [ $p = 06 ] || [ $p = 6 ];then
eval; cd tombol_special_termux
eval; sh logo.sh
eval; python2 specialbutton.py
fi

if [ $p = 07 ] || [ $p = 7 ];then
eval; cd Tools_Rusmana-ID
eval; sh v2.sh
fi

if [ $p = 08 ] || [ $p = 8 ];then
eval; cd join_group_whatsaap
eval; sh wa.sh
echo
fi

if [ $p = 09 ] || [ $p = 9 ];then
eval; cd Anggota_CBHI
python2 __XcPutri__.py
eval; sh nick.sh
fi

if [ $p = 10 ];then
eval; cd channel_youtube_admin
eval; sh channel.py
fi

if [ $p = 11 ];then
eval; cd hack_instagram
eval; sh lolo.sh
fi

if [ $p = 12 ];then
eval; cd virus_marker
eval; python2 vbug.py
eval; cd virus
fi

if [ $p = 13 ];then
eval; cd chat_admin
eval; sh x.sh
fi

if [ $p = 14 ];then
eval; cd virus_prank
z= sleep 1
eval; sh logo.sh
fi

if [ $p = 15 ];then
eval; cd hack_cctv
eval; python2 scan.py
fi

if [ $p = 16 ];then
eval; cd fb-prank
eval; python2 DorkFb.py
fi

if [ $p = 17 ];then
eval; cd perkiraan-cuaca
eval; sh l.sh
fi

if [ $p = 18 ];then
eval; cd tuan-badutv3
eval; sh TUANB4DUT.sh
fi

if [ $p = 19 ];then
eval; cd spam-wa-prank
eval; sh logo.sh
fi

if [ $p = 20 ];then
eval; cd info_update
eval; sh info.sh
fi

if [ $p = 21 ];then
eval; cd jasa_admin
eval; sh admin.sh
fi

if [ $p = 22 ];then
eval; cd hack-fb
eval; python2 darkvip.py
fi

if [ $p = 23 ];then
eval; cd tools-pajaoq
eval; python2 v1.py
fi

if [ $p = 24 ];then
eval; cd send-trojans
eval; python2 trojans.py
fi

if [ $p = 25 ];then
eval; cd spam-wa
eval; node index.js
fi

if [ $p = 00 ] || [ $p = 0 ];then
echo $bi" Thanks For Ussing *_*"${W}
sleep 1
exit
fi
