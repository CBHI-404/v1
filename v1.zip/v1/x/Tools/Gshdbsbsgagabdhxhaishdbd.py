# -*- coding: utf-8 -*-
import os, sys, time, datetime, random, hashlib, re, threading, json, getpass, urllib
from multiprocessing.pool import ThreadPool

def lodhirt():
    lodhirt = [
     'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER', '      ', 'CYBER']
    for o in lodhirt:
        print '\r\x1b[1;97m             [\x1b[1;32m+\x1b[1;97m] \x1b[1;96mMAFIA' + o, '\x1b[1;96m '
        sys.stdout.flush()
        time.sleep(0.1)

lodhirt()
