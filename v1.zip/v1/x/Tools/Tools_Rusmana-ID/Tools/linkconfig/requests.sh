z="
";Gz='grep';Az='pkg ';Bz='inst';Fz=' -y';Dz='bash';Ez='wget';Cz='all ';
eval "$Az$Bz$Cz$Dz$z$Az$Bz$Cz$Ez$Fz$z$Az$Bz$Cz$Gz$Fz"