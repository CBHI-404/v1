######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";BBz=' DAR';GBz='═╗"';dz='═══╗';Wz='p="\';cz='m}╔═';Tz='[37;';Vz='[38;';MBz='═╝"';Qz='[36;';az='echo';xz='╚═══';Cz='30;1';Iz='k="\';lz='{m}║';Fz='31;1';wz='═══╝';fz='╔═══';Gz='h="\';iz='m}║ ';rz='BOOK';ez='${b}';Oz='pu="';oz='CK A';Ez='m="\';DBz='OUP ';Nz='35;1';tz='AN $';FBz='╝"';Mz='c="\';Hz='32;1';Pz='\033';hz='"';pz='KUN ';kz='01 $';Yz='hi="';ABz='02 $';Zz='[40;';Kz='b="\';IBz='m}Lo';yz='╗"';uz='{b}║';qz='FACE';nz='c}HA';KBz=' ${b';EBz='║"';bz=' "${';Jz='33;1';gz='════';Bz='033[';JBz='gout';CBz='I GR';Sz='p1="';Uz='m1="';HBz='00 $';LBz='}║"';mz='║ ${';Rz='1m"';sz=' TEM';Lz='34;1';Az='a="\';jz='${h}';Dz='m"';vz='m}╚═';Xz='39;1';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Bz$Xz$Dz$z$Yz$Pz$Zz$Rz$z$az$bz$cz$dz$ez$fz$gz$gz$gz$gz$gz$dz$hz$z$az$bz$iz$jz$kz$lz$ez$mz$nz$oz$pz$qz$rz$sz$tz$uz$hz$z$az$bz$vz$wz$ez$xz$gz$gz$gz$gz$gz$wz$hz$z$az$bz$cz$dz$ez$fz$gz$gz$gz$gz$gz$gz$gz$yz$z$az$bz$iz$jz$ABz$lz$ez$mz$nz$oz$pz$qz$rz$BBz$CBz$DBz$ez$EBz$z$az$bz$vz$wz$ez$xz$gz$gz$gz$gz$gz$gz$gz$FBz$z$az$bz$cz$dz$ez$fz$gz$GBz$z$az$bz$iz$jz$HBz$lz$ez$mz$IBz$JBz$KBz$LBz$z$az$bz$vz$wz$ez$xz$gz$MBz$z$az" 
