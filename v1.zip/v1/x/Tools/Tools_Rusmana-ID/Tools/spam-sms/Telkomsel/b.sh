z="
";Fz='════';Bz=' "\0';Gz='══╝"';Az='echo';Cz='33[3';Dz='4;1m';Ez='╚═══';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz" 
