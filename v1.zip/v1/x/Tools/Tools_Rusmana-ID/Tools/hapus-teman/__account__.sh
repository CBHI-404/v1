######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Febry, Bima, Accil, Alfa           #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest, Zhum Bai Lee          #
######################################
z="
";FBz='{m}║';oz='═══"';bBz='}${n';fz='m╗"';sz='"';hz='m║"';mz='═"';gz='u="\';GBz='${v}';CBz='${p}';KCz='═╝"';iBz='h}║ ';dz='m╔"';Jz='33;1';lz='════';BCz='═══╝';Tz='37;1';Sz='p="\';MBz='LS $';NBz='{h}}';uz='echo';Pz='\033';FCz='═╗"';BBz='{h}{';Zz='[40;';Wz='p2="';UBz='}║"';pBz='Pert';Fz='31;1';Iz='k="\';OBz='v}${';qz='x="$';rBz='an F';xz='═══╗';nz='q="$';Rz='1m"';PBz=' ${p';HCz='m}Lo';EBz='h}}$';YBz='{o}═';eBz='h}╔═';sBz='b  $';ICz='gout';vBz='{u}$';XBz='{n}$';wBz='{h} ';LBz=' TOO';Gz='h="\';IBz='h}{ ';Dz='m"';mBz='║ ${';Cz='30;1';xBz='ON $';WBz='═══$';GCz='00 $';KBz='ULAN';Yz='hi="';Lz='34;1';TBz='}${m';yz='╔═══';Mz='c="\';Xz='[39;';JCz=' ${b';lBz='{h}║';Oz='pu="';RBz='TUS ';yBz='{u}"';Vz='[38;';cBz='} <═';jBz='${m}';CCz='╚═══';pz='j="$';rz='o="╚';Uz='m1="';Az='a="\';ABz='m}║$';ACz='h}╚═';tz='n="╝';Bz='033[';vz=' "${';VBz='m}╚═';DCz='{o}$';kBz='01 $';bz='r';oBz='pus ';gBz='   ╔';Hz='32;1';iz='v="\';QBz='}STA';Qz='[36;';hBz='╗"';Ez='m="\';ez='t="\';SBz='${h}';ZBz='═══>';kz='{b}═';tBz='{b}║';dBz='{n}"';wz='m}╔═';fBz='${b}';ECz='{x}$';aBz=' ${o';JBz='KUMP';DBz='NO${';nBz='p}Ha';cz='s="\';HBz='  ${';Nz='35;1';uBz='   $';az='clea';qBz='eman';jz='z="$';Kz='b="\';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Bz$Tz$Dz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$Bz$Lz$dz$z$ez$Bz$Lz$fz$z$gz$Bz$Lz$hz$z$iz$Bz$Fz$hz$z$jz$kz$lz$lz$lz$lz$lz$mz$z$nz$kz$oz$z$pz$kz$lz$lz$mz$z$qz$kz$oz$z$rz$sz$z$tz$sz$z$az$bz$z$uz$vz$wz$xz$yz$lz$lz$lz$lz$xz$yz$lz$xz$sz$z$uz$vz$ABz$BBz$CBz$DBz$EBz$FBz$GBz$HBz$IBz$CBz$JBz$KBz$LBz$MBz$NBz$HBz$OBz$ABz$BBz$PBz$QBz$RBz$SBz$TBz$UBz$z$uz$vz$VBz$WBz$XBz$YBz$lz$lz$lz$lz$ZBz$aBz$bBz$cBz$lz$WBz$dBz$z$uz$z$uz$vz$eBz$xz$fBz$yz$lz$lz$lz$lz$xz$gBz$lz$hBz$z$uz$vz$iBz$jBz$kBz$lBz$fBz$mBz$nBz$oBz$pBz$qBz$rBz$sBz$tBz$uBz$vBz$wBz$xBz$yBz$z$uz$vz$ACz$BCz$fBz$CCz$lz$lz$lz$lz$BCz$uBz$DCz$ECz$dBz$z$uz$z$uz$vz$eBz$xz$fBz$yz$lz$FCz$z$uz$vz$iBz$jBz$GCz$lBz$fBz$mBz$HCz$ICz$JCz$UBz$z$uz$vz$ACz$BCz$fBz$CCz$lz$KCz$z$uz$z$uz" 
