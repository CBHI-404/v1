clear
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
hi='\033[0;30m' #Hitam
echo $cy""
python2 txt.py
sleep 2
echo
python2 txt2.py
sleep 2
echo $pur"["$ku"√"$pur"]"$i"Succses"
echo
echo
echo
pkg install figlet
pkg update && pkg upgrade -y
pkg install w3m
pkg install ruby
pkg install lolcat
pkg install toilet
pkg install nano
pkg install python2
pkg install python3
pkg install python2 -y
pkg install root-repo
pkg install curl
pip install requests
pip2 install mechanize
sleep 3
clear
echo $me"•>"$cy"figlet "$i"√Succses"
sleep 5
echo $me"•>"$cy"nano "$i"√Succses"
sleep 5
echo $me"•>"$cy"update dan upgrade "$i"√Succses"
echo $me"•>"$cy"w3m "$i"√Succses"
sleep 5
echo $me"•>"$cy"ruby "$i"√Succses"
sleep 5
echo $me"•>"$cy"lolcat "$i"√Succses"
echo $me"•>"$cy"toilet "$i"√Succses"
sleep 5
echo $me"•>"$cy"python2 "$i"√Succses"
sleep 5
echo $me"•>"$cy"python3 "$i"√Succses"
sleep 5
echo $me"•>"$cy"root-repo "$i"√Succses"
echo $me"•>"$cy"curl "$i"√Succses"
sleep 5
echo $me"•>"$cy"wc "$i"√Succses"
sleep 5
echo $me"•>"$cy"request "$i"√Succses"
sleep 5
echo $me"•>"$cy"mechanize "$i"√Succses"
sleep 5
echo $ku""
python2 txt3.py
echo
sleep 3
python2 txt4.py
sleep 2
sh g1.sh
