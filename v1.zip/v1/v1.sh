cd x
sh p.sh
